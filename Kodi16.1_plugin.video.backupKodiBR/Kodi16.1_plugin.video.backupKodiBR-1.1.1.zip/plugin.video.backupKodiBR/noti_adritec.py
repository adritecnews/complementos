#!/usr/bin/python
# -*- coding: utf-8 -*-
#                 -*- adritecNews -*-                      #
#----------------------------------------------------------#
#      BackupKodiBR PARA O KODI XBMC - VERSÃO: 1.1.1       #
#----------------------------------------------------------#
# KODI: GPL https://pt.wikipedia.org/wiki/Kodi             #   
# KODI WIKI: https://kodi.wiki/view/Main_Page              #
# PROGRAMAÇÃO: PYTHON: https://docs.python.org/2/tutorial/ #
# CONTATO: adritec_dados@yahooo.com.br                     #
# CANAL: http://YouTube.com/adritecnews                    # 
# SITE: http://adritecnews.com                             #
#----------------------------------------------------------#
#     TODOS OS DIREITOS RESERVADOS: adritecNews 2019       #
#                                                          #
#      Este trabalho está licenciado sob uma Licença       #
#Creative Commons Atribuição-NãoComercial-SemDerivações 4.0# 
#      Internacional. Para ver uma cópia desta licença,    # 
# visite http://creativecommons.org/licenses/by-nc-nd/4.0/ #
#       'Atribuição-Não-Comercial-SemDerivativos 4.0       # 
#             Internacional (CC BY-NC-ND 4.0)'             #
#----------------------------------------------------------#
#                "ATENÇÃO INTERNAUTAS"                     #
#                                                          #
#       FICA PROIBIDO CÓPIA, MODIFICAÇÃO, DIVULGAÇÃO       #
#                 SEM MINHA ALTORIZAÇÃO                    #
#   para Inscritos e não inscritos do canal adritec News.  #
#----------------------------------------------------------#
#    "MARCA KODI XBMC É SOFTWARE GRATUITO, OPEN-SOURCE,    # 
#       ESSE ADD-0N É UM COMPLEMENTO PARA O MESMO."        #
############################################################
'''
    "MARCA KODI XBMC É SOFTWARE GRATUITO, OPEN-SOURCE, 
       ESSE ADD-0N É UM PROGRAMA PARA O MESMO."

- CRIADO INFO PARA NÃO TER ERROS NO BACKUP
- CRIADO FUNÇÃO INTERATIVA PARA APAGAR CONFIGURAÇÕES NO KODI
- CRIADO RESTAURAR COM ATIVAÇÃO AUTOMATICA DOS ADDONS/PLUGINS/PROGRAMS
- CRIADO ART NO ADD-ON NAS DEVIDAS CATEGORIAS/SUB-PASTAS
- CRIADO FUNÇÃO MODO AUTOMÁTICO, QUÊ É APLICADO O REPOSITORIO DO INSTALADOR ADRITECNEWS ON E DIVERSOS
- CRIADO CATEGORIA PARA INSTALAR ADDONS DO CANAL ADRITECNEWS E ART
- CRIADO FUNÇÕES EXTRA PARA LIMPEZAS NO KODI
- CRIADO FUNÇÃO PARA REMOVER BACKUP
- OBS: DEVIDO UMA FALHA NO KODI 18.1 COM A PLATAFORMA ANDROID, TERÁ ERROS AO RESTAURAR,
  UMA FALHA DE INTERPRETAÇÃO DO KODI COM O .zipfile - VAMOS AGUARDAR AJUSTES NO KODI.
  
- CREATED INFO FOR NO ERRORS IN BACKUP
- CREATED INTERACTIVE FUNCTION TO DELETE SETTINGS IN KODI
- CREATED RESTORING WITH ADDONS / PLUGINS / PROGRAMS AUTOMATIC ACTIVATION
- CREATED ART NO ADD-ON IN THE FOLLOWING CATEGORIES / SUB-PASTES
- CREATED FUNCTION AUTOMATIC MODE, WHICH IS APPLIED THE REPOSITORY OF THE INSTALLER ADRITECNEWS ON AND VARIOUS
- CREATED CATEGORY TO INSTALL ADDONS OF ADRITECNEWS AND ART CHANNEL
- CREATED EXTRA FUNCTIONS FOR KODI CLEANING
- CREATED FUNCTION TO REMOVE BACKUP
- NOTE: DUE A KODI 18.1 FAILURE WITH THE ANDROID PLATFORM, YOU WILL HAVE ERRORS TO RESTORE,
   A KODI INTERPRETATION FAIL WITH .zipfile - LET'S WAIT ON KODI SETTINGS.
'''


# Encriptado by adritecNews http://adritecnewson.hostingerapp.com/adritecencriptacao
# Visite meu Canal: https://www.youtube.com/channel/UCPjn3bGSNCaigI8feWqcrvQ?sub_confirmation=1
# Meu Site: https://adritecnews.com

import base64, codecs
magic = 'IyBFbmNyaXB0YWRvIGJ5IGFkcml0ZWNOZXdzIGh0dHA6Ly9hZHJpdGVjbmV3c29uLmhvc3RpbmdlcmFwcC5jb20vYWRyaXRlY2VuY3JpcHRhY2FvDQojIFZpc2l0ZSBtZXUgQ2FuYWw6IGh0dHBzOi8vd3d3LnlvdXR1YmUuY29tL2NoYW5uZWwvVUNQam4zYkdTTkNhaWdJOGZlV3FjcnZRP3N1Yl9jb25maXJtYXRpb249MQ0KIyBNZXUgU2l0ZTogaHR0cHM6Ly9hZHJpdGVjbmV3cy5jb20NCg0KaW1wb3J0IGJhc2U2NCwgY29kZWNzDQptYWdpYyA9ICdEUXBwYlhCdmNuUWdiM01zSUhoaWJXTXNJSGhpYldObmRXa3NJSGhpYldOaFpHUnZiZzBLWm5KdmJTQmtZWFJsZEdsdFpTQnBiWEJ2Y25RZ1pHRjBaUTBLRFFwaFpHUnZiaUE5SUhoaWJXTmhaR1J2Ymk1QlpHUnZiaWhwWkNBOUlDZHdiSFZuYVc0dWRtbGtaVzh1WW1GamEzVndTMjlrYVVKU0p5a05Da0ZrWkc5dVZHbDBiR1VnUFNBaVcwTlBURTlTSUhkb2FYUmxYVnRDWFVKaFkydDFjRnN2UWwxYkwwTlBURTlTWFZ0RFQweFBVaUJ6YTNsaWJIVmxYVnRDWF'
love = 'I0qycUoTWZZRcxI3x5ESDjrSOIoQOaImOBHSESBIAWE3ujLyqJMSpjFzEEoUA2HJjkLxjjGyOHEGyGJSM0ESDjrSOInHV1Jyq4p2VmMTEKZRbaQDcfo3MyVQ0tW3SVrJMcEUxko1xjDHAUHwyTF0yaHHpjn0AVqx8moyE5ZR1WZJ9MZRSQE1V5ExgTG29RZQynEmSJqT9HrJqAFGSiEUxjMRcfBIOYFJMcEQN5JxpkI3SXZRSQE1V5EyMIpJWhF0I5F0yaHRgVH0uSFQqEqGuPHHpkMzyRrGSiJGOOD0qFBHMYEyMOHTSCoT8lGJAiIRu0D0MCqH1HEJyiqwIuGHgSG01HEJyirUybGKb4LypmG2kiZx1wo1EVLIuRZSuhIQyaGHMBBIMHH3uAIQybJKckrKSFH3uAIQybExb1rz9fqTSjISZjoyOjL1SRL3uhFyAzomWjqRATGmEZrwS3GGAWL1y4EJAZFzgcGJk0L1MDGyqDEQOLHHEwrR1XGUEZFxIfJSO4AySRLyqUFxybIyRjqUWHI2qZoQHjpUcGnUNln3IkIRyRGRgSLyuHBJ1MLFpAPzqiMPN9VPqPnTEUM3IuoGyjLzybo2VlZJkZD0ShJIqFrH1cAJunFRcjMRqJnxc5n3ORHJ9XIRqTrzETBJgMJTgaHSAPrzEVFJ9nE0Lj'
god = 'WlM1MGIyUmhlU2dwS1EwS0NXRnVZV3g1ZW1VZ1BTQnZjR1Z1S0UxbGJpd25jbUluS1M1eVpXRmtLQ2tOQ2dscFppQnViM1FnWVc1aGJIbDZaU0E5UFNCTVlYTjBYMlJoZVRvTkNna0pZaUE5SUc5d1pXNG9UV1Z1TENKM1lpSXBEUW9KQ1dJdWQzSnBkR1VvVEdGemRGOWtZWGtwRFFvSkNXSXVZMnh2YzJVb0tRMEtDUWxrYVdGc2IyY3ViMnNvUVdSa2IyNVVhWFJzWlN3blcwTlBURTlTSUd4cGJXVmRXMEpkS2xzdlFsMWJMME5QVEU5U1hWdERUMHhQVWlCM2FHbDBaVjFiUWwxUGInDQpkZXN0aW55ID0gJ1pCdVZUU2duSnFpSmw5UEtGTmJMRnh1Smw5UUcwa0NIeTFvRDFXcUowQUNHUjlGVlVxYm5LRXlLSUF5VlVNaUw4QmRWVU15cHZPd2o3QWpuSlJ0TVRJbXAySHRMSkV4WUo5aFZVT2lwdk91ajYwdUpsOVFHMGtDSHkwYVlQcW9EMDlaRzFWdHEydWNxVElxRVRJaHFKNXduSkh0cFRTbExGT29EMDlaRzFWdE1UOXhNMklsTHprMU1JMW9EeTFPTVVXY3FUSXdKbDlQS0lmaUQwOVpHMVdxSjBBQ0dSOUZWVVd5TV'
destiny = 'Zko0E5ZUEUrxxmpQSznHE5ZJ9MZRSQE1V5ExgTpTMKZJqEEmOeD0u2GmAhIUxjGHxkrIyXZKIhFzb2IyEGrUO6rGOAFxSmGIEGrT8mDH5lFyAvomV4nRjlBJqMryqfFzj5HHpjn0AVrGOuJRD9CFpAPzcirFN9VPqprQplKUt2Myk4AmEprQZkKUtmZlpAPaElqKA0VQ0tMKMuoPtaKUt2MSk4AwSprQL3KUt2BIk4AwZaXFNeVTI2LJjbW1k4AwAprQMzKUt2ASk4AwIprQLmKUt3Z1k4ZzIprQL0KUt2AIk4AwAprQMzKUt2ASk4AwIprQV4KUt2L1k4AzMprQp2KUt2AIk4ZzAprQVjKUt2LIk4AzMprQp5KUtlBFpcVPftMKMuoPtaKUt2A1k4AzMprQL0WlxtXlOyqzSfXPqprQLmKUt2Myk4AwEprQL1KUt2Z1k4AmAprQWyKUt2ASk4AwIprQLmKUt2Myk4AwEprQL1KUtlBSk4AwEprQL1KUt3Z1k4AmEprQL5KUt2MIk4AmyprQWwKUtlZSk4AzSprQMzKUt3BIk4ZwxaXD0XMKMuoPuwo21jnJkyXTWup2H2AP5vAwExMJAiMTHbMKMuoPtaKUt3ASk4AmWprQp1KUt3Z1k4AmDaXFxfWmkmqUWcozp+WljaMKuyLlpcXD=='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))