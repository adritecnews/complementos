#!/usr/bin/python
# -*- coding: utf-8 -*-

#                 -*- adritecNews -*-                      #
#----------------------------------------------------------#
#     ADD-ON FEED NEWS PARA O KODI XMBC - VERSÃO: 1.0.0    #
#----------------------------------------------------------#
# KODI: GPL https://pt.wikipedia.org/wiki/Kodi             #   
# KODI WIKI: https://kodi.wiki/view/Main_Page              #
# PROGRAMAÇÃO: PYTHON: https://docs.python.org/2/tutorial/ #
# CONTATO: adritec_dados@yahooo.com.br                     #
# CANAL: YouTube.com/adritecnews                           # 
# SITE: httP://adritecnews.com                             #
#----------------------------------------------------------#
#     TODOS OS DIREITOS RESERVADOS: adritecNews 2018       #
#                                                          #
#      Este trabalho está licenciado sob uma Licença       #
#Creative Commons Atribuição-NãoComercial-SemDerivações 4.0# 
#      Internacional. Para ver uma cópia desta licença,    # 
# visite http://creativecommons.org/licenses/by-nc-nd/4.0/ #
#       'Atribuição-Não-Comercial-SemDerivativos 4.0       # 
#           Internacional (CC BY-NC-ND 4.0)'               #
#----------------------------------------------------------#
#                "ATENÇÃO INTERNAUTAS"                     #
#                                                          #
#      FICA PROIBIDO CÓPIA, MODIFICAÇÃO, DIVULGAÇÃO        #
#                SEM MINHA ALTORIZAÇÃO                     #
# Add-on desenvolvido para trazer informação para Inscrito #
#          e não inscritos do canal adritec News.          #
#----------------------------------------------------------#

import xbmc, xbmcaddon, xbmcgui

dialog = xbmcgui.Dialog()
AddonTitle = "[COLOR dodgerblue][B]adritec[/B][/COLOR][COLOR red][B]News[/B] [COLOR gold][B]ON[/B][/COLOR]"
adritec_SETTINGS = xbmcaddon.Addon()
adritec_SETTINGS.openSettings() 

class OK():
   dialog.ok(AddonTitle,'Não deixe de se [COLOR orange][B]INSCREVER-SE[/B][/COLOR] no canal [COLOR dodgerblue][B]adritec[/B][/COLOR][COLOR red][B]News[/B][/COLOR].','[B]Seja um colaborador, qualquer [COLOR lightpink]valor $$$[/COLOR].[/B]','[COLOR orange][B]e-mail[/B][/COLOR]: [COLOR aquamarine][B]adritec_dados@yahoo.com.br[/B][/COLOR].')
   exit()