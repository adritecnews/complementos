#!/usr/bin/python
# -*- coding: utf-8 -*-

#                 -*- adritecNews -*-                      #
#----------------------------------------------------------#
#     ADD-ON FEED NEWS PARA O KODI XMBC - VERSÃO: 1.0.0    #
#----------------------------------------------------------#
# KODI: GPL https://pt.wikipedia.org/wiki/Kodi             #   
# KODI WIKI: https://kodi.wiki/view/Main_Page              #
# PROGRAMAÇÃO: PYTHON: https://docs.python.org/2/tutorial/ #
# CONTATO: adritec_dados@yahooo.com.br                     #
# CANAL: YouTube.com/adritecnews                           # 
# SITE: httP://adritecnews.com                             #
#----------------------------------------------------------#
#     TODOS OS DIREITOS RESERVADOS: adritecNews 2018       #
#                                                          #
#      Este trabalho está licenciado sob uma Licença       #
#Creative Commons Atribuição-NãoComercial-SemDerivações 4.0# 
#      Internacional. Para ver uma cópia desta licença,    # 
# visite http://creativecommons.org/licenses/by-nc-nd/4.0/ #
#       'Atribuição-Não-Comercial-SemDerivativos 4.0       # 
#           Internacional (CC BY-NC-ND 4.0)'               #
#----------------------------------------------------------#
#                "ATENÇÃO INTERNAUTAS"                     #
#                                                          #
#      FICA PROIBIDO CÓPIA, MODIFICAÇÃO, DIVULGAÇÃO        #
#                SEM MINHA ALTORIZAÇÃO                     #
# Add-on desenvolvido para trazer informação para Inscrito #
#          e não inscritos do canal adritec News.          #
#----------------------------------------------------------#
import os, gui, time, datetime, random, urllib2, re
import xbmc, xbmcaddon, xbmcgui, traceback, feedparser
import zlib
import base64
def decode_base64( b64string ):
    decoded_data = base64.b64decode( b64string )
    return zlib.decompress( decoded_data , -15)
def base64_encode( string_val ):
    zlibbed_str = zlib.compress( string_val )
    compressed_string = zlibbed_str[2:-4]
    return base64.b64encode( compressed_string )	
exec(decode_base64('lVfvbuI4EP98eQpvJeRkm6awezr1kNCJbWkXqaUroLs6cRUyiQFfQ5y1ndLe6R7mdB/uCe4J9sVubAdIArRsJBLjzMzv5/H8cdoXF7e9cfcCmauFsAwFS1VAIsEUDRO6lFNKI/3ETj45HnSGw27vagDyT5NFSKKIJ0Fb310Wtdq5Sc+xo177pmONV/WDGVVGrZtMuYsTsqDYc1Zvx9e35wdopYJPWawVLdyn9vDjQXApUXPsBRENeURdnKnpydnayudOf9C97b1u5ZEKyXgCit1zkF9fryqy0Ghdtnvt/vBgrSlJiFCgd93uXd21rzov6V3zkMTsDxoNlGDJzHGci86Hu6tXOA6oUiDt4rZij0SgiKaZIN/+/fYPxx5qQYxMSSwpdj60B53xZadz0et8GdjomSuVyubpqVoyJaQMFtQMFRXjTMJN8TFMn/6i/7RycOw4P+jLiegUxXzmLuTMRzF9pHFLh1dwfXtleHtNR7NmU2SXAVQuNRNEksjKozc2IrVKp9+/7TeRoCoTyUrRSrW2pAASHQN/5GN0jJQgIZ2Q8CGYcrEgakyfQtczNoyeJrmKchDHJ1qpHDer2c1aPMcsEBz8SfCUCvXsSrMtDR+FiRJxq1GHK1+kpW3gZhkLvrAk4kvXyHnBDhuWnb0MjtyF80jijO6CU+K5uQdsvyGLCb6hqUId84BMQEQi2jQbeVTQ9RFEzZxnb9ARuAUMudTzy9uQeyiMKRGH+Gg3353qYDqMiZTohidMceEa4PxPbk5jj8cMpsZjV9J46qO3RMwkPN4+LPUoF9SXfh+kNInA+vmcJDMK4T8UGXXWImujPMlTSlrJyFgvGNO+wltS2DsAbQ1mlzeg4hEKi8snv9NQ7VtYAVpA7vAFbDKwquAtnnP/ANbKbRURqaAYWUxaeLftgpJghcJyDuUbJVxVYAMy4UL16deMSqXpNQsxbrK5Il9xkPVQWWl7cVtuNSVlS+l7W19Vf0mYGrIFRbpMjhpn9br/M/x+gt/7ev1+xBLlvlyMJ4IJdAn71NO92PPutzDYLOGCforJ82uV/UPMwatElOt50ZazZ6zdbnJHw1AIiIBJPQSzn1lEueutHG+qcpHSvv0w0V8MEN+q6dYDjSdRYArqIfT5KDNd6A3e9i80U1haMf1289b1AjxxnglBE2UrxwUjwKELEYZYAptTb/xY9+Fef39/ENuQsCcCYY4i9u1veM/1GAhN2cw2zv+oRGQC9Yi8SH0nbxOt4fxB91nXO3iPKkGuw++Si7bOKHcVi9537UnRxGkpaXasaSIoeTCzzroGKEhjexCpVoD1gOgzxCYQofsipvdEaBi34b87a3hNkNKt+ktN4lpevsI514VlhDH0b3y/4ZO3UTJqvjur379QoEIOAREat+S1Xy0ptW6qFOqCqI+6vY2gJn9c0FurbSRAJCKKKhgH6wH0qFQP3LWcj3CN+KgWodoE1X5FtY/N2k2zNih4WkXjWB/vkLa5ATjZ2Ne3iMaKwIIgxiLZeg/lZg+rlTlNZmrIVBh0LQNUS+HMHOu2mrq4XiC07Zvbu+EBzsm3aP3mpU3K02BX+8zfFT0EZ5pyWsi+CReg8mq5LRRanSWNkiH9RWQGLTNMiYDjbGAebulQXE4MQFvIjdoIQwUSjEpcLuVQk+iTFfvTZGce5Pqhedd9N6bQbrQ176Theb5pWc36X6PVCu+3cHO6RmlkEMoyiqmYWhnXmB5hMwXJFEDtjeFA7OLfEsgvXJxQ1QmRT9gA8coOSHVsWhBb1gpJpzH1DsB3WTaJmZzDAciYkmnMYPYYe6P6/R7DrHyuxjUZZAYMo9q6J+t9NJOlj4LVJSv6sPos5nit7ht3eC/q5JgbHfO/rJMxWL3uQld3Xfcoj8HgaREf+WjzAeuj1aujqnoQ8RsekbjSDCDT4eV6yp7KmyiFU+H/'))
                
if __name__ == '__main__': Servico()