#!/usr/bin/python
# -*- coding: utf-8 -*-
# encoded by pyprotect
# http://gabrielsilva.tk/pyprotect
#                 -*- adritecNews -*-                      #
#----------------------------------------------------------#
#  INSTALADOR DE ADD-ONS PARA O KODI XBMC - VERSÃO: 2.2.2  #
#----------------------------------------------------------#
# KODI: GPL https://pt.wikipedia.org/wiki/Kodi             #   
# KODI WIKI: https://kodi.wiki/view/Main_Page              #
# PROGRAMAÇÃO: PYTHON: https://docs.python.org/2/tutorial/ #
# CONTATO: adritec_dados@yahooo.com.br                     #
# CANAL: http://YouTube.com/adritecnews                    # 
# SITE: http://adritecnews.com                             #
#----------------------------------------------------------#
#     TODOS OS DIREITOS RESERVADOS: adritecNews 2018       #
#                                                          #
#      Este trabalho está licenciado sob uma Licença       #
#Creative Commons Atribuição-NãoComercial-SemDerivações 4.0# 
#      Internacional. Para ver uma cópia desta licença,    # 
# visite http://creativecommons.org/licenses/by-nc-nd/4.0/ #
#       'Atribuição-Não-Comercial-SemDerivativos 4.0       # 
#             Internacional (CC BY-NC-ND 4.0)'             #
#----------------------------------------------------------#
#                "ATENÇÃO INTERNAUTAS"                     #
#                                                          #
#       FICA PROIBIDO CÓPIA, MODIFICAÇÃO, DIVULGAÇÃO       #
#                SEM MINHA ALTORIZAÇÃO                     #
#    Add-on desenvolvido para fazer AJUSTES no seu KODI,   #
#   para Inscritos e não inscritos do canal adritec News.  #
#----------------------------------------------------------#
import base64, codecs
magic = 'IyAtKi0gY29kaW5nOiB1dGYtOCAtKi0NCiMgICAgICAgICAgICAgICAgIC0qLSBhZHJpdGVjTmV3cyAtKi0gICAgICAgICAgICAgICAgICAgICAgIw0KIy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0jDQojICBJTlNUQUxBRE9SIERFIEFERC1PTlMgUEFSQSBPIEtPREkgWEJNQyAtIFZFUlPDg086IDIuMC4wICAjDQojLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSMNCiMgS09ESTogR1BMIGh0dHBzOi8vcHQud2lraXBlZGlhLm9yZy93aWtpL0tvZGkgICAgICAgICAgICAgIyAgIA0KIyBLT0RJIFdJS0k6IGh0dHBzOi8va29kaS53aWtpL3ZpZXcvTWFpbl9QYWdlICAgICAgICAgICAgICAjDQojIFBST0dSQU1Bw4fDg086IFBZVEhPTjogaHR0cHM6Ly9kb2NzLnB5dGhvbi5vcmcvMi90dXRvcmlhbC8gIw0KIyBDT05UQVRPOiBhZHJpdGVjX2RhZG9zQHlhaG9vby5jb20uYnIgICAgICAgICAgICAgICAgICAgICAjDQojIENBTkFMOiBodHRwOi8vWW91VHViZS5jb20vYWRyaXRlY25ld3MgICAgICAgICAgICAgICAgICAgICMgDQojIFNJVEU6IGh0dHA6Ly9hZHJpdGVjbmV3cy5jb20gICAgICAgICAgICAgICAgICAgICAgICAgICAgICMNCiMtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIw0KIyAgICAgVE9ET1MgT1MgRElSRUlUT1MgUkVTRVJWQURPUzogYWRyaXRlY05ld3MgMjAxOCAgICAgICAjDQojICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICMNCiMgICAgICBFc3Rl'
love = 'VUElLJWuoTuiVTImqZBuVTkcL2IhL2yuMT8tp29vVUIgLFOZnJAyofBaLFNtVPNtVPNwQDbwD3WyLKEcqzHtD29goJ9hplOOqUWcLaIcj6sQb28gGfBwo0AioJIlL2yuoP1GMJ1RMKWcqzUQc8B1MKZtAP4jVlNAPvZtVPNtVPOWoaEypz5uL2yiozSfYvODLKWuVUMypvO1oJRtL8BmpTyuVTEyp3EuVTkcL2Ihj6quYPNtVPNwVN0XVlO2nKAcqTHtnUE0pQbiY2AlMJS0nKMyL29goJ9hpl5ipzpioTywMJ5mMKZiLaxgozZgozDiAP4jYlNwQDbwVPNtVPNtVPqOqUWcLaIcj6sQb28gGfBwol1Qo21ypzAcLJjgH2IgETIlnKMuqTy2o3ZtAP4jVPNtVPNtVPZtQDbwVPNtVPNtVPNtVPNtVRyhqTIlozSwnJ9hLJjtXRAQVRWMYH5QYH5RVQDhZPxaVPNtVPNtVPNtVPNtVPZAPvZgYF0gYF0gYF0gYF0gYF0gYF0gYF0gYF0gYF0gYF0gYF0gYF0gYF0gYF0gYF0gYF0gYF0gYF0gYF0gVj0XVlNtVPNtVPNtVPNtVPNtVPNvDIESGfBUj4ACVRyBIRIFGxSIIRSGVvNtVPNtVPNtVPNtVPNtVPNtVPNtVPZAPvZtVPNtVPNtVPNtVPNtVPNtVPNtVPNtVPNtVPNtVPNtVPNtVPNtVPNtVPNtVPNtVPNtVPNtVPNtVPNtVj0XVlNtVPNtVPOTFHAOVSOFG0yPFHECVRCQx1OWDFjtGH9RFHMWD0UQu8BQGljtERyJIHkUDpBUj4ACVPNtVPNtVPZAPvZtVPNtVPNtVPNtVPNtVPNtH0IAVR1WGxuOVRSZIR9FFIcOj4sQt08tVPNtVPNtVPNtVPNtVPNtVPNtVPNwQDbwVPNtVRSxMP1iovOxMKAyoaMioUMcMT8tpTSlLFOzLKcypvOOFyIGIRIGVT5iVUAyqFOYG0EWYPNtVPZAPvZtVPOjLKWuVRyhp2AlnKEiplOyVT7Qb28tnJ5mL3WcqT9mVTEiVTAuozSfVTSxpzy0MJZtGzI3pl4tVPZAPvZgYF0gYF0gYF0gYF0gYF0gYF0gYF0gYF0gYF0g'
god = 'LS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIw0KaW1wb3J0IHpsaWINCmltcG9ydCBiYXNlNjQNCmRlZiBkZWNvZGVfYmFzZTY0KCBiNjRzdHJpbmcgKToNCiAgICBkZWNvZGVkX2RhdGEgPSBiYXNlNjQuYjY0ZGVjb2RlKCBiNjRzdHJpbmcgKQ0KICAgIHJldHVybiB6bGliLmRlY29tcHJlc3MoIGRlY29kZWRfZGF0YSAsIC0xNSkNCmRlZiBiYXNlNjRfZW5jb2RlKCBzdHJpbmdfdmFsICk6DQogICAgemxpYmJlZF9zdHIgPSB6bGliLmNvbXByZXNzKCBzdHJpbmdfdmFsICkNCiAgICBjb21wcmVzc2VkX3N0cmluZyA9IHpsaWJiZWRfc3RyWzI6LTRdDQogICAgcmV0dXJuIGJhc2U2NC5iNjRlbmNvZGUoIGNvbXByZXNzZWRfc3RyaW5nICkNCgkNCmV4ZWMoZGVjb2RlX2Jhc2U2NCgneFZiTmJ1TTJFRDViVHpFSUVGQkNYTm9ydENoZ3dDM3ljd213UDBXM2h3S0JZZEFTSlhORGtTcEo3U1k1OVZuYVE5Rm42SzE1a3o1Smg5U3YwN2pZM1VOclFCWTVQeCtITXgrSEVsV3RqWU83WFpYTnd6L0xjNjNhWWRtSWRsRExwaFFvMUhZTzl0NjJ3dmNGRGtxcGQ1Rm9NZXkrY1VMMnM4WklLWGJwdkgzM1VzUDdrUk1Wandxaks1UlozWmlNVzRxR05HZTV0dEFaVlV3MWpxdU02U2c2OTRGZFg4R2F0T0hRMnVqU3NJcXkzQWpITThVL1dLR3NZMUtHUFZnUzFTeTdaU1czdVRDQXZ6V0V3S2t6VEZuSkhQK091WDJzTGEzeFRkOXBvV0ppYTU0SkpsZUx4VjVYZk5FaUxYb2dNaWNrU1NLM2I2cWRZa0xhNDdCUGtSckxUYzRjVy93d09KTWt5dEZDbHdqUjVadGVCVUdjUkpZN0oxU3ZDbkhRa0lJNG9TVjNiMXQxSkRLdGZQaWQzV2ZzamNBWmRMbWRFdytYMGxxVmZwdVJLS0FMSXlhc2NUcVRuQ21Td0hvTnhKbUdrMVUwQS9S'
destiny = 'q1WeqaSfMJSGJyu1GmOwBTyjJwOiA3WyIacdoxqBp0WArRkbBHD3o05kERRkq2yWLGR5HGN4ZzuiIzqdFaWLnaqEEHf1MHkRpwIJp211JRHeAHISH1AhIR1DnJuVpQElMTEEJTIDo2cuHUMLpJEOpQy1GRqdIlgEZTggZ3WOIyNjI1H3oIynpaOFpzg3nJqjqRSSoz9urxtmDGuIpJckMxu4rR9UqHAOMHk2pHW5MUD0HKEiEGu6qJy6EUuYASHjFSN5HwAPoJElMHyUIT9eLyEaAz9DrKunJJkxn2g4GSOFEIOhn1WLEyWXAH5BG0t3oxM6AQIjL3McDxH0nRufI0kTBULjrFgJrIAnMFfkF0yWD1E2ZSECDJV2HSO0qQqVJRyaqQIyp3NjMKZeqQO2FRc6MIqvoQVeX0V1ESyUESxmEwI1Y2M2A2knoxq4qIMeEFguJyMlqmADGvgzFHqhnHcZJHxip0L1BH1aMUycIKt4Y0jjD1chAKS4FUMmFJ9jDacnDx1YX2cOqzWzoaHmJT1VX0qyEIubZHSHZTIzHRqwIQuaZJ1aFIb3FxS4A1D0FyWhERMZJP9VM05Kp1cOLyuBM3qwGwydE2uOIaIuY2V0oF83ImVkZmEkHUcXF1yGpT1YEIIbJzqUrIunL3WmoTWIJxp1ZUDmpmyyG3MUpl9OERkABRcPE0j3IKZiqTgxLH42LxIABGyGrUtiDGWKrxg1oyAeJSElnSuHo2jmqTcJHR84DmWxFHE0pIqlq0kRZRAAIGuwFUOWp3MFAJkkIyOuJyyyASMeAxcxpacDEKIhHxq1HP9LBH1BZHt1A3MPFzWSp0EbraczJHqRLl84qJMhEKIALxk5LxSiIFg2Hzj4HzkfEP96nGEZJJWvpTVmHlgPZ1OAGKuxFGMHrwR5nIOTAwu1Ayq2qxyRGT1PGwMWpQybGUu5L2uznyu5IISKE1ImqzAuAwuJEKV3D0WUGmWjoJSMI09cnTAmAKWyZ3HinmNjDF9DG1OkH0qaAHk4pyOTAvgOoxgerwOQo1ODE3Mdq1peLzyhImEzAQqjHJqaHJV3EmIUGT8iMTIPYmWvDx5TDKWwLIt0pGuGov9CEUIVIx0eATAHZSW2BTVaXFx='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))