#!/usr/bin/python
# -*- coding: utf-8 -*-
# encoded by pyprotect
# http://gabrielsilva.tk/pyprotect
#                 -*- adritecNews -*-                      #
#----------------------------------------------------------#
#  INSTALADOR DE ADD-ONS PARA O KODI XBMC - VERSÃO: 2.2.2  #
#----------------------------------------------------------#
# KODI: GPL https://pt.wikipedia.org/wiki/Kodi             #   
# KODI WIKI: https://kodi.wiki/view/Main_Page              #
# PROGRAMAÇÃO: PYTHON: https://docs.python.org/2/tutorial/ #
# CONTATO: adritec_dados@yahooo.com.br                     #
# CANAL: http://YouTube.com/adritecnews                    # 
# SITE: http://adritecnews.com                             #
#----------------------------------------------------------#
#     TODOS OS DIREITOS RESERVADOS: adritecNews 2018       #
#                                                          #
#      Este trabalho está licenciado sob uma Licença       #
#Creative Commons Atribuição-NãoComercial-SemDerivações 4.0# 
#      Internacional. Para ver uma cópia desta licença,    # 
# visite http://creativecommons.org/licenses/by-nc-nd/4.0/ #
#       'Atribuição-Não-Comercial-SemDerivativos 4.0       # 
#             Internacional (CC BY-NC-ND 4.0)'             #
#----------------------------------------------------------#
#                "ATENÇÃO INTERNAUTAS"                     #
#                                                          #
#       FICA PROIBIDO CÓPIA, MODIFICAÇÃO, DIVULGAÇÃO       #
#                SEM MINHA ALTORIZAÇÃO                     #
#    Add-on desenvolvido para fazer AJUSTES no seu KODI,   #
#   para Inscritos e não inscritos do canal adritec News.  #
#----------------------------------------------------------#
import base64, codecs
magic = 'IyEvdXNyL2Jpbi9lbnYgcHl0aG9uDQojIC0qLSBjb2Rpbmc6IFVURi04IC0qLQ0KaW1wb3J0IHhibWMsIHhibWNhZGRvbiwgeGJtY2d1aSwgeGJtY3BsdWdpbixvcyxzeXMNCmltcG9ydCB1cmxsaWIyLHVybGxpYg0KaW1wb3J0IHJlDQppbXBvcnQgdGltZQ0KaW1wb3J0IHppcGZpbGUNCmZyb20gZGF0ZXRpbWUgaW1wb3J0IGRhdGV0aW1lDQoNCmRwICAgICAgICAgICA9IHhibWNndWkuRGlhbG9nUHJvZ3Jlc3MoKQ0KZGlhbG9nIAkJID0geGJtY2d1aS5EaWFsb2coKQ0KYWRkb25JbmZvICAgID0geGJtY2FkZG9uLkFkZG9uKCkuZ2V0QWRkb25JbmZvDQoNCkFkZG9uVGl0bGUxID0gIltDT0xPUiBkb2RnZXJibHVlXVtCXWFkcml0ZWNbL0JdWy9DT0xPUl1bQ09MT1IgcmVkXVtCXU5ld3NbL0JdIFtDT0xPUiBnb2xkXVtCXU9OWy9CXVsvQ09MT1JdW0NPTE9SIHdoaXRlXTpbL0NPTE9SXSBbQ09MT1Igd2hpdGVdW0JdSW5mb3JtYcOnw6NvWy9CXVsvQ09MT1JdIg0KQWRkb25JRCA9J3BsdWdpbi5wcm9ncmFtLmFkcml0ZWNuZXdza'
love = 'J5mqTSfoTSxMT9hplpAPt0XL2kup3ZtL3ImqT9gMT93ozkiLJDbqKWfoTyvYxMuozA5IIWZo3OyozIlXGbAPvNtVPO2MKWmnJ9hVQ0tW01irzyfoTRiAF4jVPuLZGR7VRkcoaI4VUt4Ay82APxtDKOjoTIKMJWYnKDiAGZ3YwRkVPuYFSEAGPjtoTyeMFOUMJAeolxtD2ulo21yYmVmYwNhZGV3ZF42APOGLJMupzxiAGZ3YwRkWj0XPD0XMTIzVTEiq25fo2SxXUIloPjtMTImqPjtMUNtCFOBo25yXGbAPvNtVPOcMvOho3DtMUN6QDbtVPNtVPNtVTEjVQ0trTWgL2q1nF5RnJSfo2qDpz9apzImpltcQDbtVPNtVPNtVTEjYzAlMJS0MFuOMTEioyEcqTkyZFjvVvjaVPpfVPptWlxAPvNtVPOxpP51pTEuqTHbZPxAPvNtVPOmqTSlqS90nJ1yCKEcoJHhqTygMFtcQDbtVPNtL3ImqT9gMT93ozkiLJDbXF5lMKElnJI2MFu1pzjfVTEyp3DfVTkuoJWxLFOhLvjtLaZfVTMmYPO1pzj9qKWfBvOspTWbo29eXT5vYPOvpljtMaZfVTEjYPOmqTSlqS90nJ1yXFxAPvNtVPNtQDcxMJLtK3OvnT9inluhqJ1voT9wn3ZfVTWfo2Aep2y6MFjtMzyfMKAcrz'
god = 'UsIGRwLCBzdGFydF90aW1lKToNCiAgICAgICAgdHJ5OiANCiAgICAgICAgICAgIHBlcmNlbnQgPSBtaW4obnVtYmxvY2tzICogYmxvY2tzaXplICogMTAwIC8gZmlsZXNpemUsIDEwMCkNCiAgICAgICAgICAgIGN1cnJlbnRseV9kb3dubG9hZGVkID0gZmxvYXQobnVtYmxvY2tzKSAqIGJsb2Nrc2l6ZSAvICgxMDI0ICogMTAyNCkgDQogICAgICAgICAgICBrYnBzX3NwZWVkID0gbnVtYmxvY2tzICogYmxvY2tzaXplIC8gKHRpbWUudGltZSgpIC0gc3RhcnRfdGltZSkgDQogICAgICAgICAgICBpZiBrYnBzX3NwZWVkID4gMDogDQogICAgICAgICAgICAgICAgZXRhID0gKGZpbGVzaXplIC0gbnVtYmxvY2tzICogYmxvY2tzaXplKSAvIGticHNfc3BlZWQgDQogICAgICAgICAgICBlbHNlOiANCiAgICAgICAgICAgICAgICBldGEgPSAwIA0KICAgICAgICAgICAga2Jwc19zcGVlZCA9IGticHNfc3BlZWQgLyAxMDI0IA0KICAgICAgICAgICAgdG90YWwgPSBmbG9hdChmaWxlc2l6ZSkgLyAoMTAyNCAqIDEwMjQpIA0KICAgICAgICA'
destiny = 'tVPNtoJWmVQ0tWlHhZQWzVR1PVZXeVSgPKKEuoJShnT8tqT90LJkoY0WqVZX7VPHhZQWzVR1PWlNyVPuwqKWlMJ50oUysMT93ozkiLJEyMPjtqT90LJjcVN0XVPNtVPNtVPNtVPNtMFN9VPqJMJkiL2yxLJEyBvNyYwNlMvOYLv9mVPptWFOeLaOmK3AjMJIxVN0XVPNtVPNtVPNtVPNtMFNeCFNaITIgpT86VPHjZzD6WGNlMPptWFOxnKMgo2DbMKEuYPN2ZPxAPvNtVPNtVPNtVPNtVUA0pzyhMlN9VPqoDy1PDHyLDH5RG1fiDy0hYv4tJ0WqHR9FVRMOIx9FYPOOE1IOHxESJl9PKF4hYvpAPvNtVPNtVPNtVPNtVTEjYaIjMTS0MFujMKWwMJ50YPOgLaZfVTHfp3ElnJ5aXD0XVPNtVPNtVPOyrTAypUD6VN0XVPNtVPNtVPNtVPNtpTIlL2IhqPN9VQRjZPNAPvNtVPNtVPNtVPNtVTEjYaIjMTS0MFujMKWwMJ50XD0XVPNtVPNtVPNtVPNtMUNhL2kip2HbXD0XVPNtVPNtVPNtVPNtpzI0qKWhQDbWPDxAPvNtVPNtVPNtnJLtMUNhnKAwLJ5wMJkyMPtcBvNAPtxWPKWunKAyVRI4L2IjqTyiovtvD2ShL2IfLJEiVvxAPtxWPJEjYzAfo3AyXPx='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))