import xbmcaddon

MainBase = 'https://pastebin.com/raw/mMShRi9k'
addon = xbmcaddon.Addon('plugin.video.Jonas Gabriel')