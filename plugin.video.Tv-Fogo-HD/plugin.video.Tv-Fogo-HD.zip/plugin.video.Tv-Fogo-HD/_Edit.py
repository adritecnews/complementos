import xbmcaddon

MainBase = 'sdgasasdg196848e119918918dg981asdg19918e981ae981ge984g9481eg9a1e98gaesg09882jdjmfd'
addon = xbmcaddon.Addon('plugin.video.Tv-Fogo-HD')
