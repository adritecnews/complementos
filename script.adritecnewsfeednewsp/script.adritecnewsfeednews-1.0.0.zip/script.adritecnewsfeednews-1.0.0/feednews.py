#!/usr/bin/python
# -*- coding: utf-8 -*-

#                 -*- adritecNews -*-                      #
#----------------------------------------------------------#
#     ADD-ON FEED NEWS PARA O KODI XMBC - VERSÃO: 1.0.0    #
#----------------------------------------------------------#
# KODI: GPL https://pt.wikipedia.org/wiki/Kodi             #   
# KODI WIKI: https://kodi.wiki/view/Main_Page              #
# PROGRAMAÇÃO: PYTHON: https://docs.python.org/2/tutorial/ #
# CONTATO: adritec_dados@yahooo.com.br                     #
# CANAL: YouTube.com/adritecnews                           # 
# SITE: httP://adritecnews.com                             #
#----------------------------------------------------------#
#     TODOS OS DIREITOS RESERVADOS: adritecNews 2018       #
#                                                          #
#      Este trabalho está licenciado sob uma Licença       #
#Creative Commons Atribuição-NãoComercial-SemDerivações 4.0# 
#      Internacional. Para ver uma cópia desta licença,    # 
# visite http://creativecommons.org/licenses/by-nc-nd/4.0/ #
#       'Atribuição-Não-Comercial-SemDerivativos 4.0       # 
#           Internacional (CC BY-NC-ND 4.0)'               #
#----------------------------------------------------------#
#                "ATENÇÃO INTERNAUTAS"                     #
#                                                          #
#      FICA PROIBIDO CÓPIA, MODIFICAÇÃO, DIVULGAÇÃO        #
#                SEM MINHA ALTORIZAÇÃO                     #
# Add-on desenvolvido para trazer informação para Inscrito #
#          e não inscritos do canal adritec News.          #
#----------------------------------------------------------#

import os, gui, time, datetime, random, urllib2, re
import xbmc, xbmcaddon, xbmcgui, traceback 
from lib import feedparser

ADDON_ID      = 'script.adritecnewsfeednews'
adritec_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = adritec_SETTINGS.getAddonInfo('name')
SETTINGS_LOC  = adritec_SETTINGS.getAddonInfo('profile')
ADDON_PATH    = adritec_SETTINGS.getAddonInfo('path').decode('utf-8')
ADDON_VERSION = adritec_SETTINGS.getAddonInfo('version')
ICON          = adritec_SETTINGS.getAddonInfo('icon')
FANART        = adritec_SETTINGS.getAddonInfo('fanart')
LANGUAGE      = adritec_SETTINGS.getLocalizedString


DEBUG         = adritec_SETTINGS.getSetting('Ativar depuração') == 'false'
BASE_FEEDNEWS   = 'https://twitrss.me/twitter_user_to_rss/?user=adritec'

					
def log(msg, level=xbmc.LOGDEBUG):
    if DEBUG == False and level != xbmc.LOGERROR: return
    if level == xbmc.LOGERROR: msg += ' ,' + traceback.format_exc()
    xbmc.log(ADDON_ID + '-' + ADDON_VERSION + '-' + msg, level)

def getProperty(string1, cntrl=10000):
    return xbmcgui.Window(cntrl).getProperty(string1)
          
def setProperty(string1, value, cntrl=10000):
    try: xbmcgui.Window(cntrl).setProperty(string1, value)
    except Exception as e: log("setProperty, falhou! " + str(e), xbmc.LOGERROR)

def clearProperty(string1, cntrl=10000):
    xbmcgui.Window(cntrl).clearProperty(string1)

class Monitor(xbmc.Monitor):
    def __init__(self, *args, **kwargs):
        self.pendingChange = True

        
    def onSettingsChanged(self):
        log('onSettingsChanged')
        self.pendingChange = True
        
class Servico(object):
    def __init__(self):
        random.seed()
        self.myMonitor = Monitor()
        self.startService()
        
        
    def startService(self):
        while not self.myMonitor.abortRequested():
            if self.myMonitor.pendingChange == True:
                self.myMonitor.pendingChange = False
                adritec_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
                waitTime   = [1800,900,600,300][int(adritec_SETTINGS.getSetting('Abrir FeedNews'))]
                ignorePlay = adritec_SETTINGS.getSetting('Bloquear') == 'false'
            
           
            if xbmc.Player().isPlayingVideo() == True and ignorePlay == True:
                log('startService, ignorar durante a reprodução!')
                continue

          
            if xbmcgui.getCurrentWindowDialogId() in [10140,10103]:
                log('startService, caixa de diálogo de configurações aberta!')
                continue
        
            self.chkFEED()
            
           
            if self.myMonitor.waitForAbort(waitTime) == True:
                log('startService, waitForAbort/pendingChange')
                break
    

    def testString(self):
        
        a = ''
        for i in range(1,281): a += 'W%s'%random.choice(['',' '])
        return a[:280]
        
        
    def correctTime(self, tweetTime):
        log('correctTime, IN tweetTime = '+ tweetTime)
        tweetTime  = datetime.datetime.strptime(tweetTime, '%a, %d %b %Y %H:%M:%S')
        td_local   = tweetTime - datetime.timedelta(seconds=3600)
        tweetTime  = td_local.strftime('%a, %d %b %Y %I:%M:%S %p').lstrip('0')
        log('correctTime, OUT tweetTime = '+ tweetTime)
        return tweetTime
        
        
    def chkFEED(self):
        log('chkFEED')
        try:
            isRandom = int(adritec_SETTINGS.getSetting('FeedNews')) == 1
            feed     = feedparser.parse(BASE_FEEDNEWS)
            items    = feed['entries']
            index    = {True:random.randint(0,(len(items)-1)),False:0}[isRandom]
            item     = items[index]
            title    = ((item['title']).replace('\n','').replace('\t','').replace('\r','').rstrip())
            pdate    = self.correctTime(item.get('published','').split('+')[0].rstrip())
            if getProperty('%s.update' %ADDON_ID) == pdate: return
            setProperty('%s.titulo'%ADDON_ID,title)
            setProperty('%s.update'%ADDON_ID,pdate)
            ui = gui.GUI("adritec.xml", ADDON_PATH, "adritec")
            ui.doModal()
            del ui
        except: pass
                
if __name__ == '__main__': Servico()