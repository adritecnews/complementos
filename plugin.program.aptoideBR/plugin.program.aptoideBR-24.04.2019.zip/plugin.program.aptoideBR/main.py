# -*- coding: utf-8 -*-
#                 -*- adritecNews -*-                      #
#----------------------------------------------------------#
# INSTALADOR DE .APK PARA O KODI XBMC - VERSÃO: 24.04.2019 #
#----------------------------------------------------------#
# KODI: GPL https://pt.wikipedia.org/wiki/Kodi             #   
# KODI WIKI: https://kodi.wiki/view/Main_Page              #
# PROGRAMAÇÃO: PYTHON: https://docs.python.org/2/tutorial/ #
# DOC/API: https://co.aptoide.com/webservices/docs         #
# CONTATO: adritec_dados@yahooo.com.br                     #
# CANAL: http://YouTube.com/adritecnews                    # 
# SITE: http://adritecnews.com                             #
#----------------------------------------------------------#
#     TODOS OS DIREITOS RESERVADOS: adritecNews 2018       #
#                                                          #
#      Este trabalho está licenciado sob uma Licença       #
#Creative Commons Atribuição-NãoComercial-SemDerivações 4.0# 
#      Internacional. Para ver uma cópia desta licença,    # 
# visite http://creativecommons.org/licenses/by-nc-nd/4.0/ #
#       'Atribuição-Não-Comercial-SemDerivativos 4.0       # 
#             Internacional (CC BY-NC-ND 4.0)'             #
#----------------------------------------------------------#
#                "ATENÇÃO INTERNAUTAS"                     #
#                                                          #
#      FICA PROIBIDO CÓPIA, MODIFICAÇÃO, DIVULGAÇÃO        #
#                SEM MINHA ALTORIZAÇÃO                     #
#    Add-on desenvolvido para fazer INSTALAÇÃO de .apk     #
#   para Inscritos e não inscritos do canal adritec News.  #
#----------------------------------------------------------#
''' 
 "MARCA KODI XBMC É SOFTWARE GRATUITO, OPEN-SOURCE, 
       ESSE ADD-0N É UM COMPLEMENTO PARA O MESMO."

Desenvolvido para baixar ou instalar .apk direto do Site 
APTOiDE, facilitando pra quem for instalar no seu Android.
ATENÇÃO: Não tenho responsabilidades sobre os .APK
SÃO DE RESPONSABILIDAES DO SITE: APTOIDE.COM

*Script Reeditado, novas funções adicionadas!

SOBRE A VERSÃO: 24.04.2019 - 24/04/19

- COMO FUNCIONA

 a: VOCÊ ESCOLHE O LUGAR QUÊ DESEJA BAIXAR O .apk (AJUSTES)
 b: PODE BAIXAR OU FAZER A INSTALAÇÃO DO .apk ESCOLHIDO
 c: TAMBÉM PODERÁ FAZER BUSCA DO APLICATIVO .apk
 d: O ADD-ON aptoideBR LISTA TODOS OS APLICATIVOS DA BASE
 e: LISTA OS MAIS BAIXADOS OU POR CATEGORIA
 
* SCRIPT RECOMPILADO *

- API: https://co.aptoide.com/webservices/docs 
- VERSÃO ORIGINAL DO PROGRAMADOR: aenemapy
- REALIZADO RECOMPILAÇÃO DO SCRIPT e MELHORIAS
  POR: Adritec News.
'''
# Encriptado by adritecNews http://adritecnewson.hostingerapp.com/adritecencriptacao
# Visite meu Canal: https://www.youtube.com/channel/UCPjn3bGSNCaigI8feWqcrvQ?sub_confirmation=1
# Meu Site: https://adritecnews.com

import base64, codecs
magic = 'IyBFbmNyaXB0YWRvIGJ5IGFkcml0ZWNOZXdzIGh0dHA6Ly9hZHJpdGVjbmV3c29uLmhvc3RpbmdlcmFwcC5jb20vYWRyaXRlY2VuY3JpcHRhY2FvDQojIFZpc2l0ZSBtZXUgQ2FuYWw6IGh0dHBzOi8vd3d3LnlvdXR1YmUuY29tL2NoYW5uZWwvVUNQam4zYkdTTkNhaWdJOGZlV3FjcnZRP3N1Yl9jb25maXJtYXRpb249MQ0KIyBNZXUgU2l0ZTogaHR0cHM6Ly9hZHJpdGVjbmV3cy5jb20NCg0KaW1wb3J0IGJhc2U2NCwgY29kZWNzDQptYWdpYyA9ICdJeUV2ZFhOeUwySnBiaTl3ZVhSb2IyNEtJeUF0S2kwZ1kyOWthVzVuT2lCMWRHWXRPQ0F0S2kwS0NncG1jbTl0SUhWeWJIQmhjbk5sSUdsdGNHOXlkQ0J3WVhKelpWOXhjMndLYVcxd2IzSjBJSE41Y3dwd1lYSmhiWE1nUFNCa2FXTjBLSEJoY25ObFgzRnpiQ2h6ZVhNdVlYSm5kbHN5WFM1eVpYQnNZV05sS0NjL0p5d25KeWtwS1FvS1lXTjBhVzl1SUQwZ2NHRnlZVzF6TG1kbGRDZ25ZV04wYVc5dUp5a0tDbWxqYjI0Z1BTQndZWEpoYlhNdVoyVjBLQ2RwWTI5dUp5a0tDbWxrSUQwZ2NHRnlZVzF6TG1kbGRDZ25hV1FuS1FvS2RIbHdaU0E5SUhCaGNtRnRjeTVuWlhRb0ozUjVjR1VuS1FvS2JtRnRaU0E5SUhCaGNtRnRjeTVuWlhRb0oyNWhiV1VuS1FvS2RHbDBiR1VnUFNCd1lYSmhiWE11WjJWMEtDZDBhWFJzWlNjcENncDVaV0Z5SUQwZ2NHRnlZVzF6TG1kbGRDZ25'
love = 'yI1MbL2ywpRAapUOvI1WcFHDjM2AUEayMImS6GT1xoTEQM25uImSeJJywpRAapQOxoIWcFHDjM2AUEayMImS6GT1xoTEQM25xFSceJJywpRAaWj0XoT92MFN9VPqwZT9XEKMJHGO0pSEGoRkXZJ1MraS5pIO0LKSHZKuZqaOwHUEwoH1XH21iZwE0D0MCnxkYI3IiF1cbGGWWZSuDpJ1AFyAgomV0LIuRLyuAF09wpQV5rR1TGwyJIH91pUcGM3OfAJSAF0EvImWWnz5YDJyAIRuuJREvJUSIGJ1hIQxmpIE5ZT9HFUEQEx9dGRgKqJ9YJzuAZxxjJSOkZUSuDJWiZ3RjoxgSMx1TpTADqTAdpUcWM25XFJkAFxE0D0MCnxkYI3IiF1cbGGWWZSuDpJcjrxyaoxcWoR1XETSLETWLpHgKMyMEZUEjISAfGRbkoIy6pKykHUEupHgKMyqfrSuDrayaGRckrIMEZUEjISAfGRbkoIy6pKykHUEuoxbkqH0lFTSLETWLo0cWZRkTGwyJIH91pUcGM3OfAJSAF0EvImVkrKSHHzSLETWLpQWWMx1XDGOJHGO0pSEGoRkXZJ1MraS5pIO0LKNlFJMAFxRjI2k4JSO6BKcALHS5pIOBBIMIG3IjryAapTj1LH1YETWKZwy6GJSOrKSDpTADqTAgomAWoRjlFUEQEx9dGRgKqJ9YJzuAZxxjJSOkoJ8mFJkZZxuuJREvJRjlBJukIRybpIOBBIMIG3IjryAapTj1LH1YETWKZxSco2SSrJ9uETSLETWLHUc5ryMHH3qkIUycWj0XM29xVQ0tW2WcDGyDH0WCLwV1oR9ao0gWD0SaFHqnrJVlZTqwoIM6LwAJrIxlIacZoKujJJx1pTWgHzkyE1M5L3yPpTWLDaMwoySaLz'
god = '1GMmFXZGhkRzl5Q2lBZ0lDQnVZWFpwWjJGMGIzSXVibUYyYVdkaGRHOXlLQ2t1Y205dmRDZ3BDZ3BsYkdsbUlHRmpkR2x2YmlBOVBTQW5iVzl6ZEY5d2IzQjFiR0Z5Y3ljNkNnbG1jbTl0SUhKbGMyOTFjbU5sY3k1c2FXSXVZWEJwSUdsdGNHOXlkQ0JoY0hSdmFXUmxDUW9KWVhCMGIybGtaUzVuWlhSUWIzQjFiR0Z5Y3lodlptWnpaWFE5YjJabWMyVjBLUW9KQ2drS1pXeHBaaUJoWTNScGIyNGdQVDBnSjBGd2NGTmxiR1ZqZENjNkNnbG1jbTl0SUhKbGMyOTFjbU5sY3k1c2FXSXVZWEJwSUdsdGNHOXlkQ0JoY0hSdmFXUmxDUW9KWVhCMGIybGtaUzVCY0hCVFpXeGxZM1FvZEdsMGJHVXNJR2xrS1FrS0NRcGxiR2xtSUdGamRHbHZiaUE5UFNBbmMyVmhjbU5vUVhCd0p6b0tDV1p5YjIwZ2NtVnpiM1Z5WTJWekxteHBZaTVoY0drZ2FXMXdiM0owSUdGd2RHOXBaR1VKQ2dsaGNIUnZhV1JsTG4nDQpkZXN0aW55ID0gJ0F5TEtXd25SU2pwUHRjUER4WFBEY3lvVHl6VlRTd3FUeWlvdk45Q0ZOYU0ySTBFMlNnTUtaYUJ0YldNYVdpb0ZPbE1LQWlxS1d3TUtaaG9UeXZZelNqbkZPY29LT2lwYUR0TEtPMG8yeXhNRHhYUEpTanFUOWNNVEhoTTJJMEUyU2dNS1piWER4WFB6SWZuSkx0TEpBMG5KOWhWUTA5VlBxYU1LRU9wVU9mbkpBdXFUeWlvYVphQnRiV01hV2lvRk9sTUtBaXFLV3dNS1pob1R5dll6U2puRk9jb0tPaXBhRHRMS'
destiny = '08jomW5rR1RrSuDFyAdpID5L01HFTuAZxxjERgCnz9HrKqZF0IwomV1oIuDrSqDEUuLHREwrJ9HrKcJISA3pIE5nJ92GwyQEx5uGGWWZRtmEJyjrxuuDaEvI01uI2yiEx9fGHgOnKSYI3qAF1cbo1E5qyy6H2chEx9wo0gCnKOuEUEZF08jomW5rR1RrSuDFyAdpID5L01HFTuAZxxjFQASnKO6FTWhFxEwHREvI1O6FJMhFxk0GRcOZT5XBJuJHGN5IyOkoJ8lI2kAEaN2HUE5raO6BJqJIIq5pQV5ZKO6DKyjoQIzoxcJnRkYG2AJIUyapSD5oUSDG3IjIHIcoxcSrIORLyqZF08jomW5rR1TAIqUrR1QJSO4I1O0rStaQDcdo3xtCFNaKUt3Zyk4AzMprQp0KUtmZIk4ZmZaQDc0paImqPN9VTI2LJjbW1k4AzEprQLkKUt2A1k4AwyprQLmWlxtXlOyqzSfXPqprQLmKUt2Myk4AwEprQL1KUt2Z1k4AmAprQWyKUt2ASk4AwIprQLmKUt2Myk4AwEprQL1KUtlBSk4AzAprQMzKUt3Ayk4AwIprQWwKUtlZSk4AzSprQMzKUt3BIk4ZwxaXFNeVTI2LJjbW1k4AwqprQMzKUt2APpcVPftMKMuoPtaKUt2Z1k4AzMprQL0KUt2AIk4AwAprQpmKUtlMIk4AwEprQL1KUt2Z1k4AzMprQL0KUt2AIk4ZwuprQL0KUt2AIk4AmAprQp0KUt2BIk4AzIprQp5KUtlL1k4ZwOprQMuKUt2Myk4AmyprQV5WlxAPzI2LJjbL29gpTyfMFuvLKAyAwDhLwL0MTIwo2EyXTI2LJjbW1k4AmEprQplKUt3AIk4AmAprQp0WlxcYPp8p3ElnJ5aCvpfW2I4MJZaXFx='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))