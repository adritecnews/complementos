#!/usr/bin/python
# -*- coding: utf-8 -*-
import re
import json
import urllib
import urllib2
import urlparse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import os
import inspect
from resources.lib.modules import downloadzip
from resources.lib.modules import control
AddonTitle = "[COLOR darkorange]Aptoide[/COLOR] [COLOR dodgerblue][B]Adritec[/B][COLOR red][B]News[/B][/COLOR][COLOR white][/COLOR]"	
	
def downloadAPK(name, url):
    if url == None: return
    dest = control.setting('download.path')
    if dest == '' or dest == None: control.infoDialog(AddonTitle,'[COLOR lime][B]*[/B][/COLOR]Caminho para download não criado!')
	

    image = control.icon

    try: headers = dict(urlparse.parse_qsl(url.rsplit('|', 1)[1]))
    except: headers = dict('')


    content = re.compile('(.+?)\sS(\d*)E\d*$').findall(name)
    transname = name.translate(None, '\/:*?"<>|')

    dest = control.transPath(dest)
    control.makeFile(dest)
    dest = os.path.join(dest, transname)

    sysheaders = urllib.quote_plus(json.dumps(headers))

    sysurl = urllib.quote_plus(url)

    systitle = urllib.quote_plus(name)

    sysimage = urllib.quote_plus(image)

    sysdest = urllib.quote_plus(dest)

    script = inspect.getfile(inspect.currentframe())

    dp = xbmcgui.DialogProgress()
    dp.create(name,"[COLOR lime][B]*[/B][/COLOR]Por favor, aguarde!")		
    try:
		downloadzip.download(url, dest, dp)
		control.infoDialog(AddonTitle,'[COLOR lime][B]*[/B][/COLOR]Baixou com Sucesso!')
    except: control.infoDialog(AddonTitle,'[COLOR lime][B]*[/B][/COLOR]Indisponivel para baixar!')
	
	
def installAPK(name, url):
    if url == None: return
    dest = control.setting('download.path')
    if dest == '' or dest == None: control.infoDialog(AddonTitle,'[COLOR lime][B]*[/B][/COLOR]Caminho para download não criado!')
	

    image = control.icon

    try: headers = dict(urlparse.parse_qsl(url.rsplit('|', 1)[1]))
    except: headers = dict('')


    content = re.compile('(.+?)\sS(\d*)E\d*$').findall(name)
    transname = name.translate(None, '\/:*?"<>|')

    dest = control.transPath(dest)
    control.makeFile(dest)
    dest = os.path.join(dest, transname)

    sysheaders = urllib.quote_plus(json.dumps(headers))

    sysurl = urllib.quote_plus(url)

    systitle = urllib.quote_plus(name)

    sysimage = urllib.quote_plus(image)

    sysdest = urllib.quote_plus(dest)

    script = inspect.getfile(inspect.currentframe())

    dp = xbmcgui.DialogProgress()
    dp.create(name,"[COLOR lime][B]*[/B][/COLOR]Por favor, aguarde...")		
    try:
		r = downloadzip.download(url, dest, dp)
		if r == '0': control.infoDialog(AddonTitle,'[COLOR lime][B]*[/B][/COLOR]Download interrompido!')
		else: control.infoDialog(AddonTitle,'[COLOR lime][B]*[/B][/COLOR]Baixou com Sucesso!')
    except: control.infoDialog(AddonTitle,'[COLOR lime][B]*[/B][/COLOR]Download interrompido!')
	
	
    apkfile = dest
    xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+apkfile+'")')