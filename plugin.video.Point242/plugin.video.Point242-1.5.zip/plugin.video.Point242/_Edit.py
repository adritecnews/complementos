import xbmcaddon

MainBase ='https://pastebin.com/raw/1GqmCCVf'
addon = xbmcaddon.Addon('plugin.video.Point242')
