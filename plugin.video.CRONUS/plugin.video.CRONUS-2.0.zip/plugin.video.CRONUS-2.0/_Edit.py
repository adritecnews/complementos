import xbmcaddon

MainBase = 'https://pastebin.com/raw/iPv8qbQT'
addon = xbmcaddon.Addon('plugin.video.CRONUS')