# Cube Play download:
# https://github.com/RH1CK/CubePlay/archive/master.zip

Addon modificado do PlaylistLoader 1.2.0 por Avigdor https://github.com/avigdork/xbmc-avigdork.

Nao somos responsaveis por colocar o conteudo online, apenas indexamos.

Link encurtado para download: http://bit.ly/CUBEPLAY

Para sugestoes e report de bugs nossa pagina no FB: http://fb.com/CubePlayKodi
