import xbmcaddon
MainBase = 'https://goo.gl/RUikDW'
addon = xbmcaddon.Addon('plugin.video.MegaBoxTV+18')