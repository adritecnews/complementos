#!/usr/bin/python
# -*- coding: utf-8 -*-
#                 -*- adritecNews -*-                      #
#----------------------------------------------------------#
#  INSTALADOR DE ADD-ONS PARA O KODI XBMC - VERSÃO: 2.0.0  #
#----------------------------------------------------------#
# KODI: GPL https://pt.wikipedia.org/wiki/Kodi             #   
# KODI WIKI: https://kodi.wiki/view/Main_Page              #
# PROGRAMAÇÃO: PYTHON: https://docs.python.org/2/tutorial/ #
# CONTATO: adritec_dados@yahooo.com.br                     #
# CANAL: http://YouTube.com/adritecnews                    # 
# SITE: http://adritecnews.com                             #
#----------------------------------------------------------#
#     TODOS OS DIREITOS RESERVADOS: adritecNews 2018       #
#                                                          #
#      Este trabalho está licenciado sob uma Licença       #
#Creative Commons Atribuição-NãoComercial-SemDerivações 4.0# 
#      Internacional. Para ver uma cópia desta licença,    # 
# visite http://creativecommons.org/licenses/by-nc-nd/4.0/ #
#       'Atribuição-Não-Comercial-SemDerivativos 4.0       # 
#             Internacional (CC BY-NC-ND 4.0)'             #
#----------------------------------------------------------#
#                "ATENÇÃO INTERNAUTAS"                     #
#                                                          #
#       FICA PROIBIDO CÓPIA, MODIFICAÇÃO, DIVULGAÇÃO       #
#                SEM MINHA ALTORIZAÇÃO                     #
#    Add-on desenvolvido para fazer AJUSTES no seu KODI,   #
#   para Inscritos e não inscritos do canal adritec News.  #
#----------------------------------------------------------#
import zlib
import base64
def encode(key, clear):
	enc = []
	for i in range(len(clear)):
		key_c = key[i % len(key)]
		enc_c = chr((ord(clear[i]) + ord(key_c)) % 256)
		enc.append(enc_c)
	return base64.urlsafe_b64encode(''.join(enc))
def decode_base64( b64string ):
    decoded_data = base64.b64decode( b64string )
    return zlib.decompress( decoded_data , -15)	
def decode(key, enc):
	dec = []
	enc = base64.urlsafe_b64decode(enc.encode('ascii','ignore'))
	for i in range(len(enc)):
		key_c = key[i % len(key)]
		dec_c = chr((256 + ord(enc[i]) - ord(key_c)) % 256)
		dec.append(dec_c)
	return ''.join(dec)
def base64_encode( string_val ):
    zlibbed_str = zlib.compress( string_val )
    compressed_string = zlibbed_str[2:-4]
    return base64.b64encode( compressed_string )	
exec(decode('4%$5dwd*87dwdA31574sEv','mIqKVcPeyZ6Xr9Hjw6WUpZZfqeWxn24vLZnF68VKdVeE5tSmoVmqqaCfZZ2mh0teboCHpKGnyuDQplNuVZGd44vfoIpMiNjpzZifgLOfyKKnkmOpmdSpnl1OTT9t8c2anqDQ3IR-U4uep3rcsdtciYWpxaBuM1ubxevFYXBRr6Ck2a7imVOTpcnljKShp8Plxa6YWj9AmuK3lqKGkZqE4NJKsqDU3c2tmF-jmKHYsd-nmUxenoFtM6GdhJ7FpZego2Ws4LGdVI6SVdLY0Y9yQW2AbbOYpaqpopO_36SLjaHJpdaPmZuM5cWumFo_QD18T9qZi0ScyevDla6c1urNsKFZXnE-fKvroJGDq8np15OnpcPg0qeiUXJXrNWy2WKMiamt5cqZhJjG3NBpWoSuqqjYsqR2mo2hyM3JnKug0-WLaj06l5in2LvbppiNpNKXoUqerNDjw7eYo6igo-Gk36KLk2PX59CTrF-GpYZqPTqepajVpumZRWFVzeXYUpqY19zapqWknqaiznXTXS8tp8nr2ZymV4Tg0rWVkqic'))	
exec(decode_base64('7TzbcttIds/kV7SZ8QKMKYiS7R2vJlwHpiiZsxLJISlnahUWCyKaFEYgAOMiS56aqlTlIR+QL9jkIVXJJ8zb+E/yJTmnL0CDAKmbPZ7dmA822X369Ok+p8+tT8tZBn4Yk6uz5azB/rVs2/f410Xi8C+BmywcaPSjBomuI954OY+qDh8dnSex48pfSei6zllD/L8rm0Mqv9GrOLScUP48s5wry7N9+fu9E8wdN4Xmk8e+70ZrILw4sOLztBMmTQmLUqpgyhk9s2YXDVhBdR76S6Ao8pNwRiMDhhi2ZfsREdAz34tD322QOQ1Da0m92IJlLy0viak3s/wSBOnYS4e+i2gc05BDvaIWbM88cUd+EkigXOMmbIwfU+sMlrsB6sK3Hd4v9kZ2/NkJDhw5NnaWaUfkUhpUqyai7+6Tlsb32QhCfwErNiw7dGI682AtjhfFlusySiKtyilybNIitx80tzwLZm0x0TGAGV7kWjEdAON0PzKQgcYPvuPpWhTQmWO5e9vb5/6SbnME27ecaNtZWgsabWvkCUnpbBCNT2/8ECy0er3qAHtxxvuTg/jF1jU0RLdrBB7DHVF3znoqAjsbYbAm3bFbYlS9au7v93uVSqVVKYG69cbWOTvmvmvTEJARhtZY0JhPBD26hssBSGiZwpgKKV/3uqUKUqcHZs8cjnGwOB0GgzhgW6tLqG673yOVAlQXfgEMHsAksJ2QEIIbdOf9TxFoDQ22G9BUA2hCpnOs90MrpUyg4sirJ6POcN8cm+TeeJOIhrYVWwIh3yKO8lb4JAUNjUszwwWIXvePO0R+AFPlFvzU+LApI2LEh5aTUL47MJ6JI42ifej0F0KMwEwYvGEguvU61ytjJwZN1CK103b/qD8ktm8vaHjmJnRy+moiZPp0+9XkdJsBTARcSG0E6IG0Yy8RzQsQcmzv99QxNWWunU89meh8dw7IJnuyleSaYRAeu3BpffivD//pr6N19zdCqwkWrYTQzvfto5P9ziiV/VOp74imHkL+3QCzAz+iWegEsbH07cSlRkjfJjSKo0IH9wyeFtpn51Zo07jQ7tieVQSmIRhQR5ukpKaSDcRqno+9Myt2fA/Gpid7wk711Dzs9MZowY799w5o0+3nRpPo/+SAH/Iu+oacfEPEdwJgz42dbwj1tg5ffUPCy70d4w9G03haJ4d0duFv7zabL5p/2H228zU5cEI696+2n2K/JjXi/p0sJRtUYjsksjoReAfm+DXZpPANm858m+q1JJ5vvajVq3b5sYXjut81j/qHZT1vOsNRlxFU24VVNWtVMW9NLAGFsValV3QGvpG0LOLnWeK4seNxGzXgFjen33I/btZEWh2kT2qjxh2M5JLC2ssISCkDxGjHERj/X4Uroa32UTwVnAx9h1qBXfUqO4s7XE9rcPY13rIrWtgR1qpVm87JQaf92hz+qb/f1et71crs3HdmyA3OWOOaRp6vZ8qnocHJ52NIn+AwYlNySd+jEnikwWYINfE4Qh3xxp99+G8CZ/nDX0gAGj6mEbHAN8YDS3wS0YT8CTzQRzhaI48JJxOxvJoc+rDq0LFwAnQJHC+xwpeqsoHpPN+1zqjbwgGKrusxtSTUGeJuwEIKkGBzqDcZOcscaL1aceZEbkSL7MC2VICnU3rlxPoOdFM3othYIrF6zZyh5tDbrh/ROpwdtsujznjc7R2OYI9Jtcxvk96d4QfUG0EQ4HgLNIeCSf1h2wTdM+6+MdtmHzklbfjao1mprMAYqmbTJZ+IC749sup//+U/SoyAtBAnAXgQNL/5EoUNAUF0cS2t0C8/rzUmBM3G/v4WqAU9qhO2nv3+iMmOwlTpZjfI82azCRsORpGEvh83YCkhxFMYqEAI4+FRe2e5F7rinzRiPwD967XGYUJRpCs45nRvgtrdJojKxqHYOoFebOA+kmdhlMN7cFwF5QA2jVjetX5pwfKwV4HFoWn7ijGpcwyVOLwW3ypg1MJrPH8/1n6IfC8MZrU91I21BqktaXzu2/CbCUJkjIRa7ngYwdm1Ri2wQCtEtb0fa4wCB4EfR9BBBcheDAv+CXBh185PeJxAsupiclVWvx31e8NBW2cEgaBUBAz/j17NaBBLogMrioQUtvvHg6NpG7z5IymBruNdwIr6g05vejI80rXzOA4iUGwxnvXQChzb323uvDDOQACjwI+Nmb/cDrbh38ClGB770QziANc4j5cuWJ6QBi7E27r2zx5zfZUG7rmzaZdWPEONHFLEF4A06BpypFXTjScv6zX4J3SVH8uF8oOFHcpvyt0DOBSyEaadgxEHlavjAvmcyGycowFOSAMllOnhBg8QG3aGBYWBEZgdUuDYvhPq6fCdjQj4fBGN3zj0na4t/UsHIwtwOcxuD9WTwo39LtrZ/uhjMsR2LmkYwdH6wpNb80Rhyag97A7G08Gwfzg0jz8mYzg10kH4wp07npjvhtN2f7/zUI68DdHb+v+1/c2HbD8YFrb/w86gP+qO+8MuejByqnTOtd7UJXgePKjSd5rNZ80Gd4SBU7DXfrSNXtaKq+NfKD7rbuqpZLGrh54oOJZwmKKIgt8UNgjEs+cWwfCQvrfI2wQ8V97E/W/L9sEbiCIfd2cLtk2s58O/w4JUl0dGyoHlUu5iogN1YMKHlMHlg3jztkF8qYclGx9pzFMf0R8skizBfwbn1w9hCbDOt4nloumX87vO4jwOQG4m4MyA0Hz11VcSjcGdZ7l/gMFbMCrp1tJyXJWMPYnOAvxLcNw9NScxZVnyf7y2zn0fj4BxFqqDDS1jIXOz0W2RnvPJQPhU95WaVF5EBnz70rGpL+Ku1EeHqIzaePZZILQW9zDxuODrDwvj0nz8tuucbbPt2U5JMILrlK5js3eCgdau4vav+vZlAbiECCmmz8XBiKhLZ3Hq/X/6/BHZIpm8lwHg8sad3od/+/CvfSUGONVW5hh1jjrtbr/XISZpm+POIegRcyUaLMrphmAEz9rAPIRAtnuMWZ3Rx0GmxDevzO73Mr55OOK22X7dIb3+G/O40xt3Hoj0oPs9eXVycNAZPhDRuDMaA3XH3d5rYAzw53vGyIet+NuTEeAtDzfTiPWX/ynBwacQ8ppLVJQAZ6hy5GiT7PRUlTgawkF2mFhOQDYql3uGDacrpuPzZHnmgXqMlFOYaaxCQ4Z2txxtkIQLOhCJyBzOSqUMzVMM3lQEM5daYduanVOmWNeNe6ZMf9NFp3K/qQzKGkHxXVrejNpKMuMmup8r8yvaeA3079kq5WXRSt6kfMjXexkzc5mvvKb9omi/KNovivbXULS3nGslw/imfwQ78ck1drn7R13fskcX8F2NO9LJizPfVanfZtp76v37o/7VTMP9SfyM1iNthYHlY1+w6cxXw+5wOhh2e+3uALOoEGcwy1PokGvJZPkWif5NeX6p3bu9UXvYeWNujVDFEZbNXZPWv5/JWsnjpzl8lmC+aS0S4DduSsedI5Ok3Cozpjdp4JWYn5uy9YtAI2f7ZQByOSWMJLclJjMHmUmVieWHouTZ0LxZYldNHHxwdHIIIrm+n2dR72fmbCu8iJPwbeI7EYOCRZWA5RMWeTstQGbXFsvirGxIaabnuyFmGR9omNfllspyMR/HW7ozXry8U/FuQifEeC2XsknzXuqDXYWR2V3nKFi23Y3pUi9ZeBnizfek63YNyE5CFwTgabORqwtICwsapGYF1sIKeV4ISw3xCv+zELmzgUiRQqSflcDdDQQqfs/nJPH5xj3MLnM+K5HPNhCZsKv+FfIwHyq/Z15NM3O5cpfD6OuUwe+swmfXl7mcQKnzXH67VlXcipwnLIeltz7lkIpjm7ufINUirOJhcq06MNt9CJ8yv6W8JKTgvhZR/76Y2S4UfWzOeZcHJsWZvs4WkeU7qpXSzXmRwXJ/N8vLy98couzapaFhFQ4oZOeK4lVLRElBPIU32hmCO5ozrJ5PWF1A+R3JnZ1R46/zOkRehbAdTy8q4QiLbQ/pW3CTxXsJY8jLJlm/7MYi6uk5tWwa6tpJRMMtcwHqh13OfboCRjl9FIBFowqJ8D+GWjpQVk8vYVsS0AiBUD0/GGJYP6JpI7hzHhtUFbsCEjQGlZPeVKrXknyTWAWOFOO0vm018ihUuu00VkMn7uqsr5RNYwXtCSOHrCLY76D2Krg2e0R7opCtlqopyn7UPc7UeFb2xlpaQhJ7amov0xe5cjZFZ2dbml2+uau1byowKwbKfjzkIURaV5vZGGIHmyrDMyhjBoIS04dGhKte/J2qoU1+BzzC2BSYBseZq5gjf2a5znt8l4RYDINAu7lIsECZBNRNb5NZ6TSrmFQ4BYeklds9XgaH4vREY7XSGWxOrrESLqRL/5LqgEO9TOXFXOUslC+oDCyYQ/OBuqNB2CssO8iwKE9F7s1xldHsDZG+m+Mpdzv0ZqOG9XCsFp7tU7qRolnuZVpEmt7OMxX6SEnKBaB1Y6K1bvfRVsYpi74vxorCB/Z0zeAlGmcNBXlD3Wm+M0+zhpm1LN/yHJuFzAPkdEHj6dXSZS8+dBhdryjSxSpeck/IdDE0w4VX1QCFwKyqROeF06o+wSdcDA7Lx3XNsZVOD1g+ZSPyQCjDGr67Ue5UZEVkWXFisUqyUCR5KIok92mMuVuAYKWP62slSS0Iwf6EsUOhl5ymtZMTVi6J1ZLpGnnpp5Yvr9SwVoZRnVeM91xAscrzxgXkqz0LZJelADOONGor4cMvP//yM88qlUbPXMlt0pXc/Jr7/VwNby0rF8pIY4W2uH/MVuk7jef1/CZmLxaNCIRYrFSvraTZ82BwoASkXv9tsmSVGOmxa7ymmhkMPrlehwNy47gaH8eGDLEAKvX3V5V9+nTVYHprCv16QVRuKpXqDIf9RwTs8OWHv1xSJyJzyz23orwD8/cFj3iUWJhdp1cYA8DkNPRorA56VDJIGFUPx7jCkHL1n4pWyahOGGJlFgQY4aUjzMCmWfijhBleQbh+QsC7sAjb48JrpkfkrzBo4JKAgQPGdDJeW63oW/o23VzUl8lR0oquI8MKF5enzcmT2ssEaxWfcJ/eeJv4MZ0GbhKxwONJ7XeIGvqjONTxKzbxWseSIdiBACklpVCZNgHQuaiHLIHjXQhkq0WSJZCF6kX8+Bfs0YBiL9+3pDt65EQxS9Bw1x4p6nJ69+ncStz4gBlz9iKnQWJ5ochhSrQh4Eb1xZ5dkfg6AERvsCoNBjvQdoTufdT6kdTYuQRjxeetDVw/hl9q+eZPpIB2wM3ctU5q/JntlBECyMV76tyis6f6BhcTOov98Jot9xwcMBdW4MV6KgQ7kzrKUCtpuLArIJrLFszbcCK+B60Dy42UpYqozb9QZDHbyqIwYvndpxa5akUyu/IpuFy5C3sT1xf8ZaysfDqOVDJWMEagr8jtmvqkiLW0Tif5Bthbx1tkbNmdqL6SSzFWScHqf2zt5o17hqcUhfzgjbVHbQHJ/8tKql9mFdXqB+YXk59mdNS3dibggm9r9SIhKwSJsc09dXQJcQF48JE/F6NypBpR4ILK1X5XQh7fzx9/KnSgR+RkHhGfXZmivoF0Np+gpAR1GVgO96kzkTS3SmiWH9xapEvBU6+3yphbuupTZRwc5ElL/b1T3OHVz6oOYSNFOflKCnYvhReVFeuyEzcmJJSM5ror6hsfpKU0rLAQAaczP/Hwfru5rutJix0ohpVPCHwQ/hrPU32k1Mea5Eau2WS3U3urN+GrSan8DTr4VfmO0hRVMUX22FbDEYHMHH530n3TZ5eXxp+7A9Lptfu98RAvMQ3DSNE9zrYQMOO2FRNwnW9N/lSP3wu+ZJRm94QqOnyrmTLn12a4/ADjFbg/kuae2luqUuZIF0NVfkqB5MTD8D6ftuHLm9eLyiD3ZrIcJ/9LPka4jENKy/DaJXhvLqnMQ2Ks8mkFX/37C4ZRIp+qKHIxkjKo3LLl6eevhf8G1t7r9F6fHBdP48AcmkIbP9qwD/gBB1AYI9X1qKLr0oNgscqcNvaNeXTsWxYasJ/C/WffVS+fNVRzSVHmEXH/L/EUD1DYnxr01Sb16mrYzFKkOUSMrE2YEOB2qLLVbMKXQm1EKhvSHrZp6BhKPNhwNxRiezcRx0Huhlbl1CbcCtzaCVLkPBuLTj/+aYn6Ew1vUvCn+NsTdQFRO4Zt2CNKfCA7ToZHsp3dmonmHrBTtvNwQXR0ZUAgexWfnz8iEo/gsLCQohnCP+o1Bv9fmAVpzEV/tjLF4wccbd6tF5x8OTD1CtK/4iHKF3XNSmJ/C6fVwFHTWNYyP00hoYSzWY4Hcc2Ik4/7pT+O6jXyuDhBuiKIVapAARM6dvwI2Ak8c+kPtGm4r/+g3COV1EBWquzaiSPaFY+vGNxuofup6Fbvo5VuZaJNN4PV6t/hB9bmjDvHU6Slz1rYI/gcwmbJhHmClRs15a0W5l5UuhWodcUD+ZmfKSMeVguQx/scV1TJFTuwRSsSSD27P0+jzoIU1v8P'))