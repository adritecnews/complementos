#!/usr/bin/python
# -*- coding: utf-8 -*-
#                 -*- adritecNews -*-                      #
#----------------------------------------------------------#
#  INSTALADOR DE ADD-ONS PARA O KODI XBMC - VERSÃO: 2.0.0  #
#----------------------------------------------------------#
# KODI: GPL https://pt.wikipedia.org/wiki/Kodi             #   
# KODI WIKI: https://kodi.wiki/view/Main_Page              #
# PROGRAMAÇÃO: PYTHON: https://docs.python.org/2/tutorial/ #
# CONTATO: adritec_dados@yahooo.com.br                     #
# CANAL: http://YouTube.com/adritecnews                    # 
# SITE: http://adritecnews.com                             #
#----------------------------------------------------------#
#     TODOS OS DIREITOS RESERVADOS: adritecNews 2018       #
#                                                          #
#      Este trabalho está licenciado sob uma Licença       #
#Creative Commons Atribuição-NãoComercial-SemDerivações 4.0# 
#      Internacional. Para ver uma cópia desta licença,    # 
# visite http://creativecommons.org/licenses/by-nc-nd/4.0/ #
#       'Atribuição-Não-Comercial-SemDerivativos 4.0       # 
#             Internacional (CC BY-NC-ND 4.0)'             #
#----------------------------------------------------------#
#                "ATENÇÃO INTERNAUTAS"                     #
#                                                          #
#       FICA PROIBIDO CÓPIA, MODIFICAÇÃO, DIVULGAÇÃO       #
#                SEM MINHA ALTORIZAÇÃO                     #
#    Add-on desenvolvido para fazer AJUSTES no seu KODI,   #
#   para Inscritos e não inscritos do canal adritec News.  #
#----------------------------------------------------------#
import zlib
import base64
def decode_base64( b64string ):
    decoded_data = base64.b64decode( b64string )
    return zlib.decompress( decoded_data , -15)
def base64_encode( string_val ):
    zlibbed_str = zlib.compress( string_val )
    compressed_string = zlibbed_str[2:-4]
    return base64.b64encode( compressed_string )

exec(decode_base64('ZZDBbsMgDIbP5SlQL22liEq759Cul0pTU027RTmQmCBLBEdAtG5PvwTCOmkczM/vzzaAw0gu8Ec7dEWMEoBsknrCJEYzabQF+cJ/eYapZHLGYPtSpD27TmUVcPjV3zj2aBTrHQ0z4mlynfJirhMggTxfuY5scGQSBzKopUlO5jNjMPLnKvNdxQWlIX13pOcRfn9gEA2+2fyD5mR86NX29GwSLXFa4v4gtAqnzDAW5QcGo8pt/Vq9Ve8cCLRyrZlUU58bCQ6D6urjuamPEWhWzilYgJv69EuWr7YmE/3q9rdmmyZdL7zcpX8X4/IiOYh1gp37oPVBGhMv7Hc/'))
exec(decode_base64('1VbrbupGEP5tnmJk6ch2DzFJetQLCkhwYloULkfAiapGFC3eNWxje9HuOkBfo4/QH1V/V32CvFhnjU2AJL39qY4lLjv7zc7lmxkvZRFsknhGiSYzQh/GTGueLtRMxNRV/Cfm1StWCWjYtn2FIJKGjKoC2axYAFcp02sh7/MFLsNMxmHMWYqYhIlMNy/Or2rPpQfwWKzVijFqtpqXBfpIeACWTEvOVPNyByuXZr9iWVchCZcsYck8iyImTRjNNwqhz8U5fLdOBGXmwIOV2ZSM0J0oIqEWMvftmTBPQm2fhavaszRh7uANGKMVC/3NZLpPfMWq0Nd4GLD1p8rDUUbMKs9/nlQkQcjtnpiD5T8j5ISKIxIKK/+SguIxPKwl12zWur6djYPJpDv4Zjz7rt9zIx4jC3lo5otHkAoNQvkropc+23CllWvO2wFzkHnWXC9BrFi636yCvbY9IAqiJ5h5Ij+37ZZeeYVHZSRlVbimGtCnWafbC1CvAbCZJ6GvJUlVTDT7gC65pWs/Cp66DvIXchLXa7WlSFgtU0waEw5UwTnNlI8OOJ5XsfpBv/SttLFguptGokfmLHbt8VZplvj9nEBXC01iz0bFzigICuW/VOxIxnbKRqv9sdMJRrPOTksyX2Vz17n74fzs66lTdZxqcewplKfaLQUe1ODzcn/c/T7A/T34M7g4v3xX/FQsLbd1uBled28PooxiQbT7usvtjMf01swPkdreXf3dFN1hm5CtdHlYAy6+qGCtVqxwKXjIUEAx92Lhb5lKBYb0ftgbjoAKumByHmdseteeEmrID+9q7eldLQdMC5xk1ABwFiizC4V4gUPayIeDF3TWSzxsCmdQyuEEEG5JOg163X530BrBZNS6bfWDwWQ4LnEOVgaejvl+/HnUbUGvezsKsOhBsQxuBOXGah0ceAtKS7fkBqpOmyjsSgEpAZURwPZ+/F1yAjF/QFLBuJwfsutsePzt+KQnKt+irN9G6gMVinhJIEsI9tLjr4+/CCBzwjfC9310FPMaG5YaZWpjnFTT1irmIZHQ+jgZ7qNCtrB3S2KQqrqZOU9dWvbVUZdallHasdtEnS/r+9GB5L4+uffRmEo0HWVZLFbs77Xz9+8L2ubzfEygsCgwce+2KBXphGscNIa/CUlIuhRYbGW+caTwlOM6FIl4KfW5uapzUmYfhISIPAhZxYLEA0LOQOSFACsiCZAi25ixUKQRX2SSIFN/MOX7hwVqOtmr4DDGYFh8xMW5yfRR686wB2f3bDsXRFLXuE6yWDdOfYUlFhwmrmEXTgschQs2nbT6rcG3Q7geFkMArgPAKh+1rlulP2byfDL8/2fu2zvuI8H3/P+v1OcvNpPw2dFb7UhikoNzmJig/Dw0l9NG/qd77fkG+6Rc3KJeKRjbPqgR859TytJGhyAbULytzf1ALfGqAwTKE4CkFHaXBSN+IDisDTBX2IN2fvo3p2b3NkuD4B0p+lT0BSWx65V3Cvdpj6v3JpcyYdT14OBGUdxdMuQBL0UHGhj6hG20i/1gZzo6+8ou7BUahVd/Ag=='))